package com.surya.service;

import static com.surya.ShortUrlConstants.SHORT_URL;
import static com.surya.ShortUrlConstants.URL;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.testng.Assert.assertEquals;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.surya.dao.ShortUrlDAO;

public class ShortUrlServiceTest {

	@Mock
	private ShortUrlDAO shortUrlDAO;

	@InjectMocks
	private ShortUrlService shortUrlService = new ShortUrlService();

	@BeforeMethod
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	public Long createShortUrl(String url) {
		Long shortUrl = shortUrlDAO.getShortUrlByUrl(url);
		if (shortUrl == null) {
			shortUrl = shortUrlDAO.insertShortUrl(url);
		}
		return shortUrl;
	}

	public String getUrlByShortUrl(long shortUrl) {
		return shortUrlDAO.getUrlByShortUrl(shortUrl);
	}

	@Test
	public void createShortUrlTest() {
		when(shortUrlDAO.getShortUrlByUrl(URL)).thenReturn(1l);
		Long actualShortUrl = shortUrlService.createShortUrl(URL);
		assertEquals(actualShortUrl, SHORT_URL);
		verify(shortUrlDAO, times(1)).getShortUrlByUrl(URL);
		verify(shortUrlDAO, times(0)).insertShortUrl(URL);
	}

	@Test
	public void createShortUrlInsertShortTest() {
		when(shortUrlDAO.getShortUrlByUrl(URL)).thenReturn(null);
		when(shortUrlDAO.insertShortUrl(URL)).thenReturn(SHORT_URL);
		Long actualShortUrl = shortUrlService.createShortUrl(URL);
		assertEquals(actualShortUrl, SHORT_URL);
		verify(shortUrlDAO, times(1)).getShortUrlByUrl(URL);
		verify(shortUrlDAO, times(1)).insertShortUrl(URL);
	}

	@Test
	public void getUrlByShortUrlTest() {
		when(shortUrlDAO.getUrlByShortUrl(SHORT_URL)).thenReturn(URL);
		String actualUrl = shortUrlService.getUrlByShortUrl(SHORT_URL);
		assertEquals(actualUrl, URL);
		verify(shortUrlDAO, times(1)).getUrlByShortUrl(SHORT_URL);
	}
}
