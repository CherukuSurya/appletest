package com.surya.rest;

import static com.surya.ShortUrlConstants.SHORT_URL;
import static com.surya.ShortUrlConstants.URL;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletContext;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.surya.service.ShortUrlService;

public class ShortUrlResourceTest {

	@Mock
	private ShortUrlService shortUrlService;

	@Mock
	private ServletContext servletContext;

	@InjectMocks
	private ShortUrlResource shortUrlResource = new ShortUrlResource();

	@Mock
	private InputStream inputStream;

	@BeforeMethod
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@GET
	@Path("/home")
	@Produces(MediaType.TEXT_HTML)
	public Response getHomePage() {
		return Response.status(200).entity(servletContext.getResourceAsStream("/WEB-INF/home.html")).build();
	}

	@Test
	public void getHomePageTest() {
		when(servletContext.getResourceAsStream("/WEB-INF/home.html")).thenReturn(inputStream);
		Response actualResopnse = shortUrlResource.getHomePage();
		assertEquals(actualResopnse.getStatus(), Status.OK.getStatusCode());
		verify(servletContext, times(1)).getResourceAsStream("/WEB-INF/home.html");

	}

	@Test
	public void createShortUrlTest() {
		when(shortUrlService.createShortUrl(URL)).thenReturn(1l);
		Response actualResopnse = shortUrlResource.createShortUrl(URL);
		assertEquals(actualResopnse.getStatus(), Status.OK.getStatusCode());
		assertEquals(actualResopnse.getEntity(), SHORT_URL);
		verify(shortUrlService, times(1)).createShortUrl(URL);
	}

	@Test
	public void createShortUrlEmptyUrlTest() {
		Response actualResopnse = shortUrlResource.createShortUrl(null);
		assertEquals(actualResopnse.getStatus(), Status.BAD_REQUEST.getStatusCode());
		verify(shortUrlService, times(0)).createShortUrl(anyString());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void createShortUrlInternlServerErrorTest() {
		when(shortUrlService.createShortUrl(URL)).thenThrow(IOException.class);
		Response actualResopnse = shortUrlResource.createShortUrl(URL);
		assertEquals(actualResopnse.getStatus(), Status.INTERNAL_SERVER_ERROR.getStatusCode());
		verify(shortUrlService, times(1)).createShortUrl(URL);
	}

	@Test
	public void getUrlByShortUrlTest() {
		when(shortUrlService.getUrlByShortUrl(SHORT_URL)).thenReturn(URL);
		Response actualResponse = shortUrlResource.getUrlByShortUrl(SHORT_URL);
		assertEquals(actualResponse.getStatus(), Status.SEE_OTHER.getStatusCode());
		verify(shortUrlService, times(1)).getUrlByShortUrl(SHORT_URL);
	}

	@Test
	public void getUrlByShortUrlNotFoundTest() {

		when(shortUrlService.getUrlByShortUrl(1l)).thenReturn(null);
		Response actualResponse = shortUrlResource.getUrlByShortUrl(SHORT_URL);
		assertEquals(actualResponse.getStatus(), Status.NOT_FOUND.getStatusCode());
		verify(shortUrlService, times(1)).getUrlByShortUrl(SHORT_URL);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void getUrlByShortUrlInternalServerErrorTest() {
		when(shortUrlService.getUrlByShortUrl(1l)).thenThrow(Exception.class);
		Response actualResponse = shortUrlResource.getUrlByShortUrl(SHORT_URL);
		assertEquals(actualResponse.getStatus(), Status.INTERNAL_SERVER_ERROR.getStatusCode());
		verify(shortUrlService, times(1)).getUrlByShortUrl(SHORT_URL);
	}

}
