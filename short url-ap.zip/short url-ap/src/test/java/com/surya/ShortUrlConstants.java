package com.surya;

public class ShortUrlConstants {

	public static final String URL = "http://www.apple.com";
	public static final Long SHORT_URL = new Long(1);
}
