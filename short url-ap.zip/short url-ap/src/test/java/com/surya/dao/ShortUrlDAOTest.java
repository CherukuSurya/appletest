package com.surya.dao;

import static com.surya.ShortUrlConstants.SHORT_URL;
import static com.surya.ShortUrlConstants.URL;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.testng.Assert.assertEquals;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.KeyHolder;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class ShortUrlDAOTest {

	@Mock
	private JdbcTemplate jdbcTemplate;

	@InjectMocks
	private ShortUrlDAO shortUrlDAO = new ShortUrlDAO();

	@Mock
	private PreparedStatementCreator preparedStatementCreator;

	@Mock
	private KeyHolder keyHolder;

	@BeforeMethod
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getShortUrlByUrlTest() {
		when(jdbcTemplate.queryForObject("SELECT id FROM urlmap WHERE url =?", Long.class, URL)).thenReturn(SHORT_URL);
		Long actualShortUrl = shortUrlDAO.getShortUrlByUrl(URL);
		assertEquals(actualShortUrl, SHORT_URL);
		verify(jdbcTemplate, times(1)).queryForObject("SELECT id FROM urlmap WHERE url =?", Long.class, URL);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void getShortUrlByUrlNullTest() {
		when(jdbcTemplate.queryForObject("SELECT id FROM urlmap WHERE url =?", Long.class, URL))
				.thenThrow(EmptyResultDataAccessException.class);
		Long actualShortUrl = shortUrlDAO.getShortUrlByUrl(URL);
		assertNull(actualShortUrl);
		verify(jdbcTemplate, times(1)).queryForObject("SELECT id FROM urlmap WHERE url =?", Long.class, URL);
	}

	@Test
	public void getUrlByShortUrlTest() {
		when(jdbcTemplate.queryForObject("SELECT url FROM urlmap WHERE id =?", String.class, SHORT_URL))
				.thenReturn(URL);
		String actualUrl = shortUrlDAO.getUrlByShortUrl(SHORT_URL);
		assertEquals(actualUrl, URL);
		verify(jdbcTemplate, times(1)).queryForObject("SELECT url FROM urlmap WHERE id =?", String.class, SHORT_URL);
	}

}
