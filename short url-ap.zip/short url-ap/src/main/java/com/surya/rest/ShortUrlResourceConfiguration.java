package com.surya.rest;

import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.stereotype.Component;
/**
 * 
 * ShortUrl resource configuration. The resource is configured with Jersey REST API implementation
 *
 */

@Component
public class ShortUrlResourceConfiguration extends ResourceConfig {
	public ShortUrlResourceConfiguration() {
		register(ShortUrlResource.class);
	}
}
