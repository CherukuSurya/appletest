package com.surya.rest;

import java.net.URI;

import javax.servlet.ServletContext;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import com.surya.service.ShortUrlService;

/**
 * 
 * ShortUrl resource
 *
 */
@Path("/shorturl")
public class ShortUrlResource {

	private static final Logger LOGGER = LoggerFactory.getLogger(ShortUrlResource.class);

	@Context
	private ServletContext servletContext;

	@Autowired
	private ShortUrlService shortUrlService;

	@GET
	@Path("/home")
	@Produces(MediaType.TEXT_HTML)
	public Response getHomePage() {
		LOGGER.info("START : Return the home page");
		return Response.status(200).entity(servletContext.getResourceAsStream("/WEB-INF/home.html")).build();
	}

	@POST
	@Produces(MediaType.TEXT_PLAIN)
	public Response createShortUrl(@QueryParam(value = "url") String url) {
		LOGGER.info("START : createShortUrl for url = {}", url);
		Long shortUrl = null;
		if (StringUtils.isEmpty(url)) {
			LOGGER.error("FAILURE : Mandatory fields are missing");
			return Response.status(400).entity("Please provide url query parameter").build();
		}
		try {
			shortUrl = shortUrlService.createShortUrl(url);
		} catch (Exception e) {
			LOGGER.error("FAILURE : Failed to create short url for url = {}", url);
			return Response.status(500).build();
		}
		LOGGER.info("SUCCESS: created short url for url = {}", url);
		return Response.status(200).entity(shortUrl).build();
	}

	@GET
	@Path("/{shortUrl}")
	@Produces(MediaType.TEXT_PLAIN)
	public Response getUrlByShortUrl(@PathParam("shortUrl") long shortUrl) {
		try {
			LOGGER.error("START : get url for  shortUrl = {}", shortUrl);
			String url = shortUrlService.getUrlByShortUrl(shortUrl);
			if (StringUtils.isEmpty(url)) {
				LOGGER.error("FAILURE : get url for shortUrl = {}", shortUrl);
				return Response.status(404).build();
			}
			LOGGER.error("SUCCESS : get url for shortUrl = {}", shortUrl);
			return Response.seeOther(new URI(url)).build();

		} catch (Exception e) {
			LOGGER.error("FAILURE : get url for shortUrl = {}", shortUrl);
			return Response.status(500).build();
		}
	}

}
