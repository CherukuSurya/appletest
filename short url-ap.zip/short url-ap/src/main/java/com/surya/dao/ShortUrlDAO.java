package com.surya.dao;

//import org.assertj.core.util.VisibleForTesting;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;

/**
 * 
 * DAO class for urlmap table
 *
 */
@Repository
public class ShortUrlDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public Long getShortUrlByUrl(String url) {
		try {
			return jdbcTemplate.queryForObject("SELECT id FROM urlmap WHERE url =?", Long.class, url);
		} catch (EmptyResultDataAccessException ex) {
			return null;
		}
	}

	public Long insertShortUrl(String url) {
		KeyHolder keyHolder = new GeneratedKeyHolder();
		String sql = "INSERT INTO urlmap(url) VALUES (?)";
		jdbcTemplate.update(connection -> {
			PreparedStatement ps = connection.prepareStatement(sql, new String[] { "id" });
			ps.setString(1, url);
			return ps;
		}, keyHolder);

		return keyHolder.getKey().longValue();
	}

	public String getUrlByShortUrl(long shortUrl) {
		return jdbcTemplate.queryForObject("SELECT url FROM urlmap WHERE id =?", String.class, shortUrl);
	}
}
