package com.surya.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.surya.dao.ShortUrlDAO;

@Service
@Transactional
public class ShortUrlService {

	@Autowired
	private ShortUrlDAO shortUrlDAO;

	public Long createShortUrl(String url) {
		Long shortUrl = shortUrlDAO.getShortUrlByUrl(url);
		if (shortUrl == null) {
			shortUrl = shortUrlDAO.insertShortUrl(url);
		}
		return shortUrl;
	}

	public String getUrlByShortUrl(long shortUrl) {
		return shortUrlDAO.getUrlByShortUrl(shortUrl);
	}

}
